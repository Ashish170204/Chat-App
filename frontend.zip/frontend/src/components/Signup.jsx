import React from 'react';

function Signup() {
  return (
    <div className="flex h-screen items-center justify-center bg-slate-700">
      <form className="bg-white shadow-md rounded-lg p-6 w-96 space-y-4 border">
        <h1 className="text-3xl font-bold text-center text-blue-600">Messenger</h1>
        <h2 className="text-xl text-center text-blue-600">Create a new Account</h2>

        <input
          type="text"
          placeholder="Full Name"
          className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring focus:border-blue-500"
        />
        
        <input
          type="email"
          placeholder="Email"
          className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring focus:border-blue-500"
        />
        
        <input
          type="password"
          placeholder="Create Password"
          className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring focus:border-blue-500"
        />

        <input
          type="password"
          placeholder="Confirm Password"
          className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring focus:border-blue-500"
        />


      {/* text and button */}
        <button
          type="submit"
          className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition">
          Sign Up
        </button>
        <p>
          Have any Account?{" "}
          <span className='text-blue-500 underline cursor-pointer ml-1 '>
          {" "}
          Login
          </span>
        </p>
      </form>
    </div>
  );
}

export default Signup;
