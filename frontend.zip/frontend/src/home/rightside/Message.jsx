import React from 'react'

function Message() {
  return (
    <div>
      <div className='p-4'>
      <div className="chat chat-end">
        <div className="chat-bubble chat-bubble-info">Hey this is ashish.</div>
      </div>

      <div className="chat chat-start">
        <div className="chat-bubble chat-bubble-accent">hey how are you ashish</div>
      </div>
    </div>
    </div>
  )
}

export default Message;
