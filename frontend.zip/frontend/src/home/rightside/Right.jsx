import React from 'react';
import Chatuser from './Chatuser';
import Messages from './Messages';
import Type from './Type';

function Right() {
  return (
    <div className="w-full bg-slate-900 text-gray-300">
      <Chatuser></Chatuser>
      <div style={{ minHeight: "calc(90vh - 8vh)" }}>
        <Messages></Messages>
      </div>
      <Type></Type>
    </div>
  );
}

export default Right;
