import React from 'react'
import User from './User';

function Users() {
  return (
    <div className=' py-2 flex-ashish overflow-y-auto ' style={{maxHeight:"calc(84vh - 5vh)"}}>
      <User></User>
      <User></User>
      <User></User>
      <User></User>
      <User></User>
      <User></User>
      <User></User>
      <User></User>
      <User></User>
      <User></User>
      <User></User>
      <User></User>
      <User></User>
      <User></User>
      <User></User>
      <User></User>
  
    
    </div>
  )
}

export default Users;
