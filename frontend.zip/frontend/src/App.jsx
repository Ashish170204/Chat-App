import React from 'react'
import Left from './home/leftside/Left';
import Right from './home/rightside/Right';
import Logout from './home/leftside1/Logout';
import Signup from './components/Signup';
import Login from './components/Login';

function App() {
  return (
    <div className="flex h-screen">
      <Logout></Logout>
      <Left></Left>
      <Right></Right>
    </div>
    // <Signup></Signup>
    // <Login></Login>
  );
}

export default App;